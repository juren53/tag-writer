.. _faq:

FAQ
===

Kivy has an `online FAQ <https://github.com/kivy/kivy/blob/master/FAQ.md>`_. It contains the answers to a number of
questions that repeatedly come up.
