Touchtracer
===========

Touchtracer is a simple example that draws lines using all the touch events
detected by your hardware.

Android
-------

You can copy/paste this directory into /sdcard/kivy/touchtracer in your
android device.

